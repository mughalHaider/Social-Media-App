# Complete Mern stack App

# cd client && npm start

# cd server && npm start

